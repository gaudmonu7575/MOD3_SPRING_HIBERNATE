package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.RegisterData;

@Repository
@Transactional
public class RegisterDAO implements IRegisterDAO{

	@PersistenceContext
	public EntityManager ent;
	
	@Override
	public ArrayList<RegisterData> datalist() {
		
		Query q=ent.createQuery("Select s from RegisterData s");
		return (ArrayList<RegisterData>) q.getResultList();
	}

}
