package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.RegisterData;

public interface IRegisterDAO {
	
	public ArrayList<RegisterData> datalist();

}
