package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.bean.RegisterData;
import com.cg.dao.IRegisterDAO;
import com.cg.service.IRegisterService;

@Controller
public class ControllerClass {

	
	@Autowired
	public IRegisterService serv;
	
	@RequestMapping("index")
	public String getIndexPage()
	{
		return "index";
	}
	
	@RequestMapping("viewallrequest")
	public String getViewData(Model m)
	{
		
		m.addAttribute("data",serv.datalist());
		return "viewallpage";
	}
}
