package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.RegisterData;

public interface IRegisterService {
	public ArrayList<RegisterData> datalist();
	}
