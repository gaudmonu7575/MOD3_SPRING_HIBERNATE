package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.RegisterData;
import com.cg.dao.IRegisterDAO;

@Service

public class RegisterServiceImpl implements IRegisterService {

	
	@Autowired
	public IRegisterDAO dao;
	
	@Override
	public ArrayList<RegisterData> datalist() {
		return dao.datalist();
	}

}